# *****************************************************************************
# * Copyright by ams OSRAM AG                                                 *
# * All rights are reserved.                                                  *
# *                                                                           *
# * IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
# * THE SOFTWARE.                                                             *
# *                                                                           *
# * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
# * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
# * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
# * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
# * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
# * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
# * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES LOSS OF USE,      *
# * DATA, OR PROFITS OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY      *
# * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
# * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
# * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
# *****************************************************************************

"""Contains an implementation of aos_com.ic_com.IcCom for I2C and GPIO access using an EVM-H5 board."""

# pylint: disable=invalid-name

import time
import typing
import corefw_c
import aos_com.ic_com

_USB_NAME = "Core FW EVM-H5"
_USB_VID = 4901
_USB_PID = 4096
_PIO_INPUT_MODE = corefw_c.PioMode.INPUT_TRIG_NONE
_PIO_OUTPUT_MODE = corefw_c.PioMode.OUTPUT_TYPE_PP
_PIO_SET_STATE = corefw_c.PioState.SET
_PIO_RESET_STATE = corefw_c.PioState.RESET


def isAmsEvmH5Available() -> bool:
    """Checks if there is a EVM-H5 board connected to this computer.

    Returns:
        True if a board has been found. False if not.
    """
    devices = corefw_c.CoreFw.list_devices(name=_USB_NAME, vid=_USB_VID, pid=_USB_PID)
    return bool(devices)


def _pioIdsFromMask(mask: int) -> typing.Set[typing.Union[corefw_c.evm_h5.PioId, int]]:
    index = 0
    output = set()
    while mask != 0:
        if mask & 1:
            try:
                pio_id = corefw_c.evm_h5.PioId(index)
            except ValueError:
                pio_id = index
            output.add(pio_id)
        mask >>= 1
        index += 1
    return output


def _maskFromPioIds(pio_ids: typing.Iterable[typing.Union[corefw_c.evm_h5.PioId, int]]):
    output = 0
    for pio_id in pio_ids:
        output |= 1 << pio_id
    return output


def _maskFromPioStates(states: typing.Dict[typing.Union[corefw_c.evm_h5.PioId, int], corefw_c.PioState]):
    set_pio_ids = filter(lambda pio_id: states[pio_id] == _PIO_SET_STATE, states)
    return _maskFromPioIds(set_pio_ids)


def _delimitedHexString(data: typing.Iterable[int],
                        delimiter: str = "",
                        prefix: str = "",
                        zero_pad: bool = True) -> str:
    if zero_pad:
        return delimiter.join(map(lambda byte: f"{prefix}{byte:02x}", data))
    return delimiter.join(map(lambda byte: f"{prefix}{byte:x}", data))


class H5Com(aos_com.ic_com.IcCom):
    """Communicates with a sensor using an an EVM-H5 board.

    Attributes:
        enable_pin: Bit mask for GPIO functions where the bit representing the enable pin is set.
        interrupt_pin: Bit mask for GPIO functions where the bit representing the interrupt pin is set.
    """

    def __init__(self,
                 log: bool = False,
                 exception_on_error: bool = True,
                 i2c_log_only: bool = False,
                 spi_log_only: bool = False,
                 interface: typing.Optional[str] = None,
                 callback: typing.Callable[[int,int,typing.Optional[corefw_c.defs.Error],bytes],None] = None,
                 callback_message_ids: typing.Sequence[int] = [] ) -> None:
        """Initializes a EVM-H5 communication instance.

        Arguments:
            log: Controls whether logging is enabled.
            exception_on_error: Controls whether an exception is raised in case of an error.
            i2c_log_only: Controls whether special I2C logging is enabled.
            spi_log_only: Controls whether special SPI logging is enabled.
            interface: Interface string of the EVM-H5 board. This is typically `COM:` followed by the name of the
                assigned COM port. For example, the interface string is `COM:COM4` for `COM4`. Set to None for automatic
                selection of the EVM-H5 board, which requires that exactly one EVM-H5 board is connected to the
                computer.
            callback: optional, function that shall be called when an interrupt is triggered (e.g. inband interrupts)
            callback_message_ids: optional, message ids that should lead to a callback

        Raises:
            ConnectionError: Automatic selection of the EVM-H5 board failed.
        """
        super().__init__(log, exception_on_error)

        if not exception_on_error:
            raise ValueError("exception_on_error set to False is not supported")

        if interface is None:
            devices = corefw_c.CoreFw.list_devices(
                name=_USB_NAME, vid=_USB_VID, pid=_USB_PID)
            if len(devices) == 1:
                interface = devices[0].interface
            else:
                raise ConnectionError("interface needs to passed as no device or more than one device was found")

        self.i2c_log_only = i2c_log_only
        self.spi_log_only = spi_log_only

        self.enable_pin = 1 << corefw_c.evm_h5.PioId.GPIO1
        self.interrupt_pin = 1 << corefw_c.evm_h5.PioId.GPIO0

        self._spi_bus: typing.Union[corefw_c.evm_h5.SpiId, int, None] = None
        self._i2c_bus: typing.Union[corefw_c.evm_h5.I2cId, int, None] = None
        self._i3c_bus: typing.Union[corefw_c.evm_h5.I3cId, int, None] = None        
        self._pio_mode: typing.Dict[typing.Union[corefw_c.evm_h5.PioId, int], corefw_c.PioMode] = {}
        if ( callback is not None ):
            self._core_fw = corefw_c.CoreFw(interface=interface,callback=callback,callback_message_ids=callback_message_ids)
        else:
            self._core_fw = corefw_c.CoreFw(interface)

        self._core_fw.connect()

        fw_info = self._core_fw.firmware_info
        self._log("__init__.connect done")
        self._log(f"Interface {interface}")
        self._log(f"ApplicationName \"{fw_info.application_name}\"")
        self._log(f"FirmwareVersion {fw_info.firmware_version}")
        self._log(f"SerialNumber {fw_info.serial_number}")
        self._log(f"CoreFwVersion {fw_info.core_fw_version}")

    def _checkUsable(self) -> None:
        if self._core_fw is None:
            raise ValueError("this H5Com instance can no longer be used as the connection has been closed")

    # ---- SPI functions ----------------------------------------------------------------------------

    def _spiLogOnly(self, msg: str) -> None:
        if self.spi_log_only:
            print(f"{(time.time() % 10):1.3f} {msg}")

    def spiOpen(self, spi_speed: int = 10000000, spi_mode: int = 3,
                spi_bus: typing.Union[corefw_c.evm_h5.SpiId, int] = corefw_c.evm_h5.SpiId.MAIN) -> int:
        """Opens the SPI interface.

        Arguments:
            spi_speed: The SPI frequency in Hz.
            spi_mode: The SPI mode number (0, 1, 2, 3).
            spi_bus: The ID of the SPI bus to use.

        Returns:
            aos_com.ic_com.IcCom.SPI_OK if successful.
        """
        self._checkUsable()
        if self._spi_bus is not None:
            raise ValueError("SPI is already open")
        self._core_fw.spi_init(spi_speed, mode=corefw_c.SpiMode(spi_mode), spi_id=spi_bus)
        self._log(f"spiOpen.SPI_OpenChannel: Status=FT_OK handle={spi_bus}")
        self._log(f"ClockRate {spi_speed}")
        self._log("spiOpen.SPI_InitChannel: Status=FT_OK")
        self._spi_bus = spi_bus
        return self.SPI_OK

    def spiClose(self) -> int:
        self._checkUsable()
        if self._spi_bus is None:
            raise ValueError("SPI is not open")
        self._core_fw.spi_shutdown(spi_id=self._spi_bus)
        self._log("spiClose.SPI_CloseChannel: Status=FT_OK")
        self._spi_bus = None
        return self.SPI_OK

    def _spiTxRx(self, tx: bytearray, rx_size: int) -> bytearray:
        self._checkUsable()
        if self._spi_bus is None:
            raise ValueError("SPI is not open")
        return bytearray(self._core_fw.spi_transfer(bytes(tx), rx_size, spi_id=self._spi_bus))

    def spiRx(self, rx_size: int) -> bytearray:
        rx = self._spiTxRx(bytearray(), rx_size)
        self._log(f"spiRx.SPI_Read status=FT_OK rxed={rx_size}")
        self._log(f"spiRx.SPI_Read: Buffer=0x{_delimitedHexString(rx)}")
        self._spiLogOnly("SPI-RX: " + _delimitedHexString(rx, delimiter=" ", prefix="0x", zero_pad=False))
        return rx

    def spiTx(self, tx: bytearray) -> int:
        self._spiTxRx(tx, 0)
        self._log(f"spiTx.SPI_Write status=FT_OK toTx={len(tx)}")
        self._log(f"spiTx.SPI_Write Buffer=0x{_delimitedHexString(tx)}")
        self._spiLogOnly("SPI-TX: " + _delimitedHexString(tx, delimiter=" ", prefix="0x", zero_pad=False))
        return self.SPI_OK

    def spiTxRx(self, tx: bytearray, rx_size: int) -> bytearray:
        rx = self._spiTxRx(tx, rx_size)
        byte_num = max(len(tx), rx_size)
        self._log(f"spiTxRx.SPI_ReadWrite status=FT_OK toTx/rxed={byte_num}")
        tx_padded = bytearray(tx) + bytearray(max(byte_num - len(tx), 0))
        rx_padded = bytearray(rx) + bytearray(max(byte_num - len(rx), 0))
        self._log(f"spiTxRx.SPI_ReadWrite TxBuffer=0x{_delimitedHexString(tx_padded)}  "
                  f"RxBuffer=0x{_delimitedHexString(rx_padded)}")
        self._spiLogOnly("SPI-TX-RX: tx=" + _delimitedHexString(tx_padded, delimiter=" ", prefix="0x", zero_pad=False) +
                         " rx=" + _delimitedHexString(rx_padded, delimiter=" ", prefix="0x", zero_pad=False))
        return rx


    # ---- I2C functions ----------------------------------------------------------------------------

    def _i2cLogOnly(self, msg: str) -> None:
        if self.i2c_log_only:
            print(f"{(time.time() % 10):1.3f} {msg}")

    def i2cOpen(self,
                i2c_speed: int = 1000000,
                i2c_bus: typing.Union[corefw_c.evm_h5.I2cId,
                                      int] = corefw_c.evm_h5.I2cId.MAIN) -> int:
        """Opens the I2C interface.

        Arguments:
            i2c_speed: The I2C frequency in Hz.
            i2c_bus: The ID of the I2C bus to use.

        Returns:
            aos_com.ic_com.IcCom.I2C_OK if successful.
        """
        self._checkUsable()
        if self._i2c_bus is not None:
            raise ValueError("I2C is already open")
        self._core_fw.i2c_init(i2c_speed, i2c_id=i2c_bus)
        self._log(f"i2cOpen.I2C_OpenChannel: Status=I2C_OK handle={i2c_bus}")
        self._log(f"ClockRate {i2c_speed}")
        self._log("i2cOpen.I2C_InitChannel: Status=I2C_OK")
        self._i2c_bus = i2c_bus
        return self.I2C_OK

    
    def i2cClose(self) -> int:
        self._checkUsable()
        if self._i2c_bus is None:
            raise ValueError("I2C is not open")
        self._core_fw.i2c_shutdown(i2c_id=self._i2c_bus)
        self._log("i2cClose.I2C_CloseChannel: Status=I2C_OK")
        self._i2c_bus = None
        return self.I2C_OK

    def _i2cTxRx(self, devaddr: int, tx: list, rx_size: int) -> bytearray:
        self._checkUsable()
        if self._i2c_bus is None:
            raise ValueError("I2C is not open")
        return bytearray(self._core_fw.i2c_transfer(devaddr, bytes(tx), rx_size, i2c_id=self._i2c_bus))

    def i2cTx(self, devaddr: int, tx: list) -> int:
        """Performs an I2C write operation. 
        Args:
            devaddr: The I2C device address.
            tx: The data to transmit.

        Returns:
            aos_com.ic_com.IcCom.I2C_OK if successful.
        """
        self._i2cTxRx(devaddr, tx, 0)
        self._log(f"i2cTx.I2C_DeviceWrite: Status=I2C_OK txed={len(tx)}")
        self._log(f"i2cTx.I2C_DeviceWrite: Buffer=0x{_delimitedHexString(tx)}")
        self._i2cLogOnly(f"I2C-TX: dev-addr=0x{devaddr:02X}: " +
                         _delimitedHexString(tx, delimiter=" ", prefix="0x", zero_pad=False))
        return self._OK

    def i2cRx(self, devaddr: int, rx_size: int) -> bytearray:
        """Performs an I2C read operation. Note that the register address has to set before with
        e.g. i2cTx or i2cTxRx.
        Args:
            devaddr: The I2C device address.
            rx_size: The number of bytes to receive.

        Returns:
            The received data as a bytearray.
        """
        rx = self._i2cTxRx(devaddr, [], rx_size)
        self._log(f"i2cRx.I2C_DeviceRead: Status=FT_OK rxed={rx_size}")
        self._log(f"i2cRx.I2C_DeviceRead: Buffer=0x{_delimitedHexString(rx)}")
        self._i2cLogOnly(f"I2C-RX: dev-addr=0x{devaddr:02X}: " +
                         _delimitedHexString(rx, delimiter=" ", prefix="0x", zero_pad=False))
        return rx

    def i2cTxRx(self, devaddr: int, tx: list, rx_size: int) -> bytearray:
        """Performs an I2C transfer consisting of a transmission followed by a reception.
        Args:
            devaddr: The I2C device address.
            tx: The data to transmit.
            rx_size: The number of bytes to receive.

        Returns:
            The received data as a bytearray.
        """
        rx = self._i2cTxRx(devaddr, tx, rx_size)
        self._log(f"i2cTxRx.I2C_DeviceWrite: Status=FT_OK txed={len(tx)}")
        self._log(f"i2cTxRx.I2C_DeviceWrite: Buffer=0x{_delimitedHexString(tx)}")
        self._i2cLogOnly(f"I2C-Tx: dev-addr=0x{devaddr:02X}: " +
                         _delimitedHexString(tx, delimiter=" ", prefix="0x", zero_pad=False))
        self._log(f"i2cTxRx.I2C_DeviceRead: Status=FT_OK rxed={rx_size}")
        self._log(f"i2cTxRx.I2C_DeviceRead: Buffer=0x{_delimitedHexString(rx)}")
        self._i2cLogOnly(f"I2C-Rx: dev-addr=0x{devaddr:02X}: " +
                         _delimitedHexString(rx, delimiter=" ", prefix="0x", zero_pad=False))
        return rx


    # ---- I3C functions ----------------------------------------------------------------------------

    def i3cOpen(self,
                i3c_speed: int = 1000000,
                i2c_allowed: bool = True,
                i3c_bus: typing.Union[corefw_c.evm_h5.I3cId,
                                      int] = corefw_c.evm_h5.I3cId.MAIN) -> int:
        """Opens the I3C interface.

        Arguments:
            i3c_speed: The I3C frequency in Hz.
            i2c_allow: allow I2C transfers in I3C mode
            i2c_bus: The ID of the I3C bus to use. (corefw_c.evm_h5.I3cId.MAIN or corefw_c.evm_h5.I3cId.SECONDARY)

        Returns:
            aos_com.ic_com.IcCom.I3C_OK if successful.
        """
        self._checkUsable()
        if self._i3c_bus is not None:
            raise ValueError("I3C is already open")        
        self._core_fw.i3c_init(i3c_speed, allow_i2c=i2c_allowed, i3c_id=i3c_bus)
        self._log(f"i3cOpen.I3C_OpenChannel: Status=I3C_OK handle={i3c_bus}")
        self._log(f"ClockRate {i3c_speed}")
        self._log("i3cOpen.I3C_InitChannel: Status=I3C_OK")
        self._i3c_bus = i3c_bus
        return self.I3C_OK

    def i3cClose(self) -> int:
        """Closes the I3C interface."""
        self._checkUsable()
        if self._i3c_bus is None:
            raise ValueError("I3C is not open")
        self._core_fw.i3c_shutdown(i3c_id=self._i3c_bus)
        self._log("i3cClose.I3C_CloseChannel: Status=I3C_OK")
        self._i3c_bus = None
        return self.I3C_OK
    
    def i3cEnableIbi(self, devaddr: int):
        """Enables IBI (In-Band Interrupt) for the specified I3C device.
        Attr: devaddr: The I3C device address for which IBI should be enabled."""
        self._checkUsable()
        if self._i3c_bus is None:
            raise ValueError("I3C is not open")
        self._core_fw.i3c_enable_ibi(addrs=[devaddr],i3c_id=self._i3c_bus)
        self._log("i3cEnableIBI: Status=I3C_OK")
        return self.I3C_OK

    def i3cDisableIbi(self):
        """Disables IBI (In-Band Interrupt) for all I3C devices on the bus."""
        self._checkUsable()
        if self._i3c_bus is None:
            raise ValueError("I3C is not open")
        self._core_fw.i3c_disable_ibi(i3c_id=self._i3c_bus)
        self._log("i3cDisableIBI: Status=I3C_OK")
        return self.I3C_OK

    def i3cWriteCCCs(self, devaddr: int, payload: dict):
        """Writes CCCs (Common Command Codes) to the specified I3C device.
        Attr: devaddr: The I3C device address for which CCCs should be written.
              payload: A dictionary containing the CCCs to be written. The keys of the dictionary 
              represent the CCC codes, and the values are bytes objects containing the corresponding CCC data payload."""
        self._checkUsable()
        if self._i3c_bus is None:
            raise ValueError("I3C is not open")
        self._core_fw.i3c_write_cccs(addr=devaddr,cccs=payload,i3c_id=self._i3c_bus)
        self._log("i3cWriteCCCs: Status=I3C_OK")
        return self.I3C_OK

    def i3cAssignDynamicAddress(self,devaddr: int) -> int:
        """Assign a dynamic address to the device.
        Attr: devaddr: The I3C device address for which a dynamic address should be assigned."""
        self._checkUsable()
        if self._i3c_bus is None:
            raise ValueError("I3C is not open")
        dcr_bcr_pid = self._core_fw.i3c_assign_dynamic_addr( addrs=[devaddr], with_reset=True, i3c_id=self._i3c_bus  )
        if devaddr in dcr_bcr_pid:
            dcr, bcr, pid = dcr_bcr_pid[devaddr]
            self._log(f"Address assigned to DCR={dcr}, BCR={bcr}, ID={pid}")
        else:
            raise ValueError(f"Could not assign I3C dynamic address {devaddr}!")
        return self.I3C_OK

    def i3cTx(self, devaddr: int, tx: list, i2c_mode: bool = False) -> int:
        """Performs an I3C write operation.
        Attr: devaddr: The I3C device address to which data should be written.
              tx: A list of bytes to be written.
              i2c_mode: If True, the operation is performed in I2C mode."""
        self.i3cTxRx(devaddr, tx, 0, i2c_mode)
        self._log(f"i3cTx: Buffer=0x{_delimitedHexString(tx)}")
        self._i2cLogOnly(f"I2C-TX: dev-addr=0x{devaddr:02X}: " +
                         _delimitedHexString(tx, delimiter=" ", prefix="0x", zero_pad=False))
        return self.I3C_OK

    def i3cRx(self, devaddr: int, rx_size: int, i2c_mode: bool = False) -> bytearray:
        """Performs an I3C read operation. Note that the register address has to set before with i3cTx.
        Attr: devaddr: The I3C device address from which data should be read.
              rx_size: The number of bytes to read.
              i2c_mode: If True, the operation is performed in I2C mode.
        Returns: The received data as a bytearray."""
        rx = self.i3cTxRx(devaddr, bytes(), rx_size, i2c_mode)
        self._log(f"i3cRx: Buffer=0x{_delimitedHexString(rx)}")
        self._i2cLogOnly(f"I2C-RX: dev-addr=0x{devaddr:02X}: " +
                         _delimitedHexString(rx, delimiter=" ", prefix="0x", zero_pad=False))
        return rx

    def i3cTxRx(self, devaddr: int, tx: list, rx_size: int, i2c_mode: bool = False ) -> bytearray:
        """Performs an I3C write followed by a read operation.
        Attr: devaddr: The I3C device address to communicate with.
              tx: A list of bytes to be written.
              rx_size: The number of bytes to read.
              i2c_mode: If True, the operation is performed in I2C mode.
        Returns: The received data as a bytearray."""
        self._checkUsable()
        if self._i3c_bus is None:
            raise ValueError("I3C is not open")
        _tx = bytes( tx )
        rx = self._core_fw.i3c_transfer( devaddr, _tx, rx_size, i2c_mode, self._i3c_bus)
        self._log(f"i3cTxRx.i3c_transfer: Status=FT_OK txed={len(tx)} TxBuffer=0x{_delimitedHexString(tx)} rxed={rx_size} RxBuffer=0x{_delimitedHexString(rx)}")
        self._i2cLogOnly(f"I3C-Tx: dev-addr=0x{devaddr:02X}: " +
                         _delimitedHexString(tx, delimiter=" ", prefix="0x", zero_pad=False))
        self._i2cLogOnly(f"I3C-Rx: dev-addr=0x{devaddr:02X}: " +
                         _delimitedHexString(rx, delimiter=" ", prefix="0x", zero_pad=False))
        return rx


    # ---- GPIO functions ----------------------------------------------------------------------------

    def _setGpioPinModeIfNecessary(self, pio_id: typing.Union[corefw_c.evm_h5.PioId, int], mode: corefw_c.PioMode,
                                   disallow_mode_change: bool = True) -> None:
        if pio_id in self._pio_mode:
            if self._pio_mode[pio_id] == mode:
                # Pin is already in the desired mode
                return
            if disallow_mode_change:
                # Pin has been set to a different mode and changing modes is disallowed
                raise ValueError("Pin is not in the required mode")
        self._core_fw.pio_init(pio_id, mode)
        self._pio_mode[pio_id] = mode

    def _deinitGpioPin(self, pio_id: typing.Union[corefw_c.evm_h5.PioId, int]) -> None:
        self._core_fw.pio_shutdown(pio_id)
        del self._pio_mode[pio_id]

    def gpioGet(self, r_mask: int) -> int:
        self._checkUsable()
        states = {}
        for pio_id in _pioIdsFromMask(r_mask):
            self._setGpioPinModeIfNecessary(pio_id, _PIO_INPUT_MODE)
            states[pio_id] = self._core_fw.pio_get(pio_id)
        value = _maskFromPioStates(states)
        self._log(f"gpioGet.FT_ReadGPIO: rmask=0x{r_mask:0x} value&rmask=0x{value:0x}")
        return value

    def gpioSet(self, w_mask: int, value: int) -> None:
        self._checkUsable()
        mask_pio_ids = _pioIdsFromMask(w_mask)
        value_pio_ids = _pioIdsFromMask(value)
        states = {}
        for pio_id in mask_pio_ids:
            states[pio_id] = _PIO_SET_STATE if pio_id in value_pio_ids else _PIO_RESET_STATE
        for pio_id, state in states.items():
            self._setGpioPinModeIfNecessary(pio_id, _PIO_OUTPUT_MODE)
            self._core_fw.pio_set(pio_id, state)
        self._log(f"gpioSet.FT_WriteGPIO: dir=0x{w_mask:0x}  value=0x{value:0x} value&wmask=0x{(w_mask & value):0x}")

    def gpioSetDirection(self, out_mask: int, out_value: int) -> None:
        self._checkUsable()

        # De-initialize all pins that are not to be configured as outputs, which allows gpioGet to re-initialize the
        # pins as inputs later. Setting all the pins to input mode is not possible as it would break I2C and SPI.
        # The self._pio_mode keys are stored in a separate list as the de-initialization modifies the size of
        # self._pio_mode, which is not supported while iterating through it.
        for pio_id in list(self._pio_mode):
            mask = 1 << pio_id
            if not mask & out_mask:
                self._deinitGpioPin(pio_id)

        # Configure all output pins as output
        pio_id = 0
        mask_pio_ids = _pioIdsFromMask(out_mask)
        value_pio_ids = _pioIdsFromMask(out_value)
        states = {}
        for pio_id in mask_pio_ids:
            states[pio_id] = _PIO_SET_STATE if pio_id in value_pio_ids else _PIO_RESET_STATE
        for pio_id, state in states.items():
            self._setGpioPinModeIfNecessary(pio_id, _PIO_OUTPUT_MODE, disallow_mode_change=False)
            self._core_fw.pio_set(pio_id, state)

        self._log(f"gpioSetDirection.FT_WriteGPIO: dir=0x{out_mask:0x}  "
                  f"value=0x{out_value:0x} value&wmask=0x{(out_mask & out_value):0x}")

    def gpioGetDirection(self) -> int:
        self._checkUsable()
        # Need to convert filter object to list because both _log and _maskFromPioIds iterate through its objects
        # (filter objects can only be iterated through once)
        output_pio_ids = list(filter(lambda pio_id: self._pio_mode[pio_id] == _PIO_OUTPUT_MODE, self._pio_mode))
        value = _maskFromPioIds(output_pio_ids)
        self._log(f"gpioGetDirection: (1=out, 0=in) 0x{value:0x}")
        return


    # ---- H5 specific functions ----------------------------------------------------------------------------

    def turnLedOff(self) -> None:
        """Turns off the STAT_LED on the EVM-H5 board.
        This function de-initializes the STAT_LED pin, turning off the LED.
        """
        self._checkUsable()
        stat_id  = getattr(corefw_c.evm_h5.PioId, "STAT_LED", 1)
        self._core_fw.pio_shutdown(stat_id)  #requires corefw 
        self._log("turnLedOff: STAT_LED turned off")

    def disconnect(self) -> None:
        """Explicitly disconnects the EVM-H5 board. It is usually not needed to call this function, since the connection
        is closed automatically during destruction of this object. If this object is not destructed despite no longer
        being needed (for example because pytest continues to hold a reference to it), this function can be called to
        free up the EVM-H5 board.

        Note that there is no way to re-establish the connection other than constructing a new instance of this class.
        """
        if self._core_fw is None:
            raise ValueError("the connection has already been closed")
        try:
            self._core_fw.disconnect()
            self._log("disconnect.disconnect done")
        finally:
            self._core_fw = None
