# *****************************************************************************
# * Copyright by ams OSRAM AG                                                 *
# * All rights are reserved.                                                  *
# *                                                                           *
# * IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
# * THE SOFTWARE.                                                             *
# *                                                                           *
# * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
# * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
# * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
# * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
# * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
# * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
# * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES LOSS OF USE,      *
# * DATA, OR PROFITS OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY      *
# * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
# * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
# * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
# *****************************************************************************
"""
This is an abstraction for I3C communication with register IO.
"""

from aos_com.ic_com import IcCom
from aos_com.hal_register_io import HalRegisterIo

class I3cHalRegisterIo(HalRegisterIo):

    # Version log 
    # 1.0 first working version
    # 1.1 automatically call dynamic address assign in the open function
    VERSION = 1.1


    def __init__(self, ic_com:IcCom, dev_addr:int ):
        """
        Constructor 
        Args:
            ic_com (IcCom): a class to be used for communication
            dev_addr (int): this should be the i3c dynamic address that was intended
        """
        super().__init__(ic_com=ic_com)
        self.dev_addr = dev_addr

    def __del__(self):
        """Cleanup."""
        pass

    # -----------------------------------------------------------------------------------        
    # functions ---------------------------------------------------------------------
    # -----------------------------------------------------------------------------------

    def open(self, speed:int=1000000) -> int:
        """Open an I3C interface.        """
        _status = self.com.i3cOpen( i3c_speed = speed, i2c_allowed = False )        
        if _status == self.com._OK:
            _status = self.com.i3cAssignDynamicAddress( self.dev_addr )
        return _status

    def close(self) -> int:
        """ Function to close a I3C interface. """
        return self.com.i3cClose( )

    def tx(self,txaddr,txdata) -> int:
        """Function to transmit given bytes on I3C """
        txaddr = self._convertToList(txaddr, "txaddr")
        txdata = self._convertToList(txdata, "txdata")
        toTx = txaddr + txdata
        self.com.i3cTxRx( self.dev_addr, bytes(toTx), 0, False )
        return self.com.I3C_OK

    def rx(self,rx_size:int) -> bytearray:
        """Function to receive bytes via I3C. """
        return self.com.i3cTxRx( self.dev_addr, bytes([]), rx_size, False )

    def txRx(self,txaddr:list,rx_size:int) -> bytearray:
        """Function to transmit and receive bytes via I3C. """
        txaddr = self._convertToList(txaddr, "txaddr")
        return self.com.i3cTxRx( self.dev_addr, bytes(txaddr), rx_size, False )

    # -----------------------------------------------------------------------------------        
    # I3C specific functions ------------------------------------------------------------
    # -----------------------------------------------------------------------------------

    def i3cAssignDynamicAddress(self) -> int:
        """Assign a dynamic address to the I3C device. """
        return self.com.i3cAssignDynamicAddress( self.dev_addr )

    def i3cEnableIbi(self) -> int:
        """Enable IBI for the I3C device. """
        return self.com.i3cEnableIbi( self.dev_addr )
    
    def i3cDisableIbi(self) -> int:
        """Disable IBI for the I3C device. """
        return self.com.i3cDisableIbi( )

if __name__ == "__main__":
    print( "This is only for including in other files")
